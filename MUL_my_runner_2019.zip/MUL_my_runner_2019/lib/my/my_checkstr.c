/*
** EPITECH PROJECT, 2019
** my_checkstr.c
** File description:
** verifier caracteres de str appartiennent a list
*/

#include"my.h"

int my_checkstr(char *str, char *check)
{
    int comp;
    int n;

    for (n = 0; str[n] != '\0'; n++) {
        comp = 0;
        while (check[comp] != '\0' && str[n] != check[comp])
            comp++;
        if (check[comp] == '\0')
            return (84);
    }
    return (1);
}