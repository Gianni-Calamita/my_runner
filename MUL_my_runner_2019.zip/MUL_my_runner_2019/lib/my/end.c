/*
** EPITECH PROJECT, 2019
** MUL_my_runner_2019
** File description:
** end.c
*/

#include"my.h"

void death(lvl_all_t *lvl_all, sfRenderWindow *window)
{
    sfClock *clock = sfClock_create();
    sfTime time;
    float second = 0;
    int compteur = 0;

    lvl_all->bomb->save = 0;
    sfSound_play(lvl_all->bomb->explosion);
    while (second != 30) {
        sfRenderWindow_clear(window, sfBlack);
        time =sfClock_getElapsedTime(clock);
        second = time.microseconds / 100000;
        if (second - lvl_all->bomb->save >= 2 && compteur < 3 ) {
            lvl_all->bomb->rect.left += 209;
            sfSprite_setTextureRect(lvl_all->bomb->sprite, lvl_all->bomb->rect);
            lvl_all->bomb->save = second;
            compteur++;
        }
        sfRenderWindow_drawSprite(window, lvl_all->decor->sprite, NULL);
        sfRenderWindow_drawSprite(window, lvl_all->sonic->death, NULL);
        if (compteur < 3)
            sfRenderWindow_drawSprite(window, lvl_all->bomb->sprite, NULL);
        sfRenderWindow_display(window);
    }
}

void set_menu_txt(end_t *end_str, decor_t *decor, int round_nb)
{
    char *str = int_to_char(round_nb);
    sfText *end = sfText_create();
    sfText *win = sfText_create();
    sfText *round = sfText_create();
    sfText *number = sfText_create();
    sfText *menu = sfText_create();

    if (round_nb <= 7) {
        sfText_setString(win, "loose");
    }
    else {
        sfText_setString(win, "WIN");
    }
    sfText_setString(end, "YOU");
    sfText_setString(round, "\n\nround:");
    sfText_setString(number, str);
    sfText_setString(menu, "retry     left");
    sfText_setFont(end, decor->font);
    sfText_setFont(win, decor->font);
    sfText_setFont(round, decor->font);
    sfText_setFont(number, decor->font);
    sfText_setFont(menu, decor->font);
    sfText_setCharacterSize(end, 100);
    sfText_setCharacterSize(menu, 100);
    sfText_setCharacterSize(round, 100);
    sfText_setCharacterSize(win, 100);
    sfText_setCharacterSize(number, 100);
    sfText_setPosition(end, (sfVector2f) {400, 200});
    sfText_setPosition(round, (sfVector2f) {400, 200});
    sfText_setPosition(number, (sfVector2f) {800, 450});
    sfText_setPosition(menu, (sfVector2f) {400, 800});
    sfText_setPosition(win, (sfVector2f) {700, 200});
    end_str->end = end;
    end_str->menu = menu;
    end_str->round = round;
    end_str->win = win;
    end_str->number = number;
}

void animation_end(lvl_all_t *lvl_all, sfRenderWindow *window, int round)
{
    end_t end;
    int selection = 0;
    int choose = 0;
    sfEvent event;
    int spam = 0;
    sfMusic *music;

    set_menu_txt(&end, lvl_all->decor, round);
    if (round > 7) {
        sfSprite_setTextureRect(lvl_all->decor->cursor, (sfIntRect) {22, 0, 21, 23});
        music = sfMusic_createFromFile(WIN);
    }
    else
        music = sfMusic_createFromFile(LOOSE);
    sfMusic_play(music);
    sfMusic_setLoop(music, sfTrue);
    while (sfRenderWindow_isOpen(window) && choose == 0) {
        if (round <= 7)
            sfRenderWindow_clear(window, sfBlack);
        if (round > 7)
            sfRenderWindow_clear(window, sfGreen);
        if (sfKeyboard_isKeyPressed(sfKeyEscape))
            sfRenderWindow_close(window);
        if (sfKeyboard_isKeyPressed(sfKeyEnter)) {
            if (selection == 0)
                choose = 1;
            else {
                sfRenderWindow_close(window);
                sfMusic_stop(music);
                return;
            }
        }
        if (sfKeyboard_isKeyPressed(sfKeyLeft) || sfKeyboard_isKeyPressed(sfKeyRight)) {
            if (selection == 0 && spam != 1) {
                sfSound_play(lvl_all->decor->choose);
                selection = 1;
                sfSprite_setPosition(lvl_all->decor->cursor, (sfVector2f) {630, 830});
                spam = 1;
            }
            if (selection == 1 && spam != 1) {
                sfSound_play(lvl_all->decor->choose);
                selection = 0;
                spam = 1;
                sfSprite_setPosition(lvl_all->decor->cursor, (sfVector2f) {300, 830});
            } 
        }
        else
            spam = 0;
        sfRenderWindow_drawText(window, end.end, NULL);
        sfRenderWindow_drawText(window, end.win, NULL);
        sfRenderWindow_drawText(window, end.round, NULL);
        sfRenderWindow_drawText(window, end.number, NULL);
        sfRenderWindow_drawText(window, end.menu, NULL);
        sfRenderWindow_drawSprite(window, lvl_all->decor->cursor, NULL);
        sfRenderWindow_display(window);
    }
    sfMusic_stop(music);
    game(window);
}

void end(lvl_all_t *lvl_all, sfRenderWindow *window, int round)
{
    death(lvl_all, window);
    animation_end(lvl_all, window, round);
}
