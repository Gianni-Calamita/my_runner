/*
** EPITECH PROJECT, 2019
** CPE_pushswap_2019
** File description:
** struct.h
*/

#ifndef STRUCT_H
#define STRUCT_H

typedef struct decor_stru
{
    sfSprite *sprite;
    sfSprite *cursor;
    sfSprite *sonic;
    sfSprite *intro_sp;
    sfSprite *title;
    sfIntRect sonic_r;
    sfIntRect c_rect;
    sfIntRect rect;
    sfMusic *theme;
    sfMusic *intro;
    sfSound *level;
    sfSound *end;
    sfClock *clock;
    sfText *round;
    sfFont *font;
    sfSound *choose;
    int song;
    int limit;
    int save;
} decor_t;

typedef struct super_sonic_str
{
    sfSprite *sprite;
    sfIntRect rect;
    sfVector2f pos;
    sfMusic *music;
} s_sonic_t;

typedef struct sonic_str
{
    sfSprite *sprite;
    sfSprite *death;
    sfIntRect rect;
    sfSound *jump;
    sfVector2f pos;
    sfVector2f speed;
    sfClock *clock;
    int limit;
    int save;
    int jumping;
    int kmh;

} sonic_t;

typedef struct B_effect_str
{
    sfSprite *spr_1;
    sfSprite *spr_2;
    sfSprite *spr_3;
    sfSprite *spr_4;
} B_effect_t;

typedef struct start_str
{
    sfSprite *sprite;
    sfVector2f pos;
    sfVector2f max_pos;
    sfVector2f max_size;
    sfVector2f size;
    int value;
} start_t;

typedef struct bomb_str
{
    sfTexture *texture;
    sfSprite *sprite;
    sfVector2f scale;
    sfIntRect rect;
    sfVector2f pos;
    sfSound *explosion;
    int save;
} bomb_t;

typedef struct end_str
{
    sfText *end;
    sfText *win;
    sfText *round;
    sfText *number;
    sfText *menu;
} end_t;

typedef struct lvl_all_str
{
    B_effect_t *B_effect;
    sonic_t *sonic;
    decor_t *decor;
    bomb_t *bomb;
    start_t *start;
    char *map;
}   lvl_all_t;

#endif