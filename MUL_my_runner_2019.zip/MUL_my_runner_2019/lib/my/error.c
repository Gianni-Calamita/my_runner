/*
** EPITECH PROJECT, 2019
** MUL_my_runner_2019
** File description:
** error.c
*/

#include"my.h"

char *map_is(char *filepath)
{
    struct stat buff;
    int fd;

    stat(filepath, &buff);
    fd = open(filepath, O_RDONLY);
    filepath = malloc(sizeof(char) * (buff.st_size + 1));
    filepath[buff.st_size + 1] = '\0';
    buff.st_size = read(fd, filepath, buff.st_size);
    return (filepath);
}

int check_file_is_map(char *filepath)
{
    int value;
    int compteur;
    char *test = "ox";

    for (value = 0; filepath[value] != '\0'; value++) {
        for (compteur = 0; filepath[value] != test[compteur]
            && test[compteur] != '\0'; compteur--)
            compteur += 2;
        if (compteur == 2)
            return ERROR;
    }
    return (0);
}

int check_error_map()
{
    int value;
    char *filepath = "ressource/map/map";

    value = open(filepath, O_RDONLY);
    if (value == -1)
        return ERROR;
    filepath = map_is(filepath);
    return (check_file_is_map(filepath));
}