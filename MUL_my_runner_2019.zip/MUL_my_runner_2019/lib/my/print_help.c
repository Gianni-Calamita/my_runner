/*
** EPITECH PROJECT, 2019
** PSU_my_sokoban_2019
** File description:
** print_help.c
*/

#include"my.h"

int check_error(char const *filepath)
{
    int value;

    value = open(filepath, O_RDONLY);
    if (value == -1)
        return (ERROR);
    return (0);
}

int print_help(void)
{
    int error;
    char *filepath = "lib/my/help";

    error = check_error(filepath);
    if (error == ERROR)
        return (ERROR);
    read_file(filepath);
    return (0);
}

void read_file(char *filepath)
{
    struct stat buff;
    int fd;
    char *file_content;

    stat(filepath, &buff);
    fd = open(filepath, O_RDONLY);
    filepath = malloc(sizeof(char) * (buff.st_size + 1));
    filepath[buff.st_size + 1] = '\0';
    buff.st_size = read(fd, filepath, buff.st_size);
    write(1, filepath, buff.st_size);
}