/*
** EPITECH PROJECT, 2019
** MUL_my_runner_2019
** File description:
** main.c
*/

#include"my.h"

int main(int ac, char **av)
{
    int error;

    if (ac == 2) {
        if (my_checkstr(av[1], "-h") == 1 
         && my_strlen(av[1]) == 2) {
            print_help();
            return (0);
        }
    }
    error = check_error_map();
    if (error == ERROR) {
        return ERROR;
    }
    runner();
    return (0);
}