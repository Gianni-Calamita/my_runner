/*
** EPITECH PROJECT, 2019
** char_to_int.c
** File description:
** trasforme un char *en int
*/

#include"my.h"

int char_to_int(char *str)
{
    int nb = 0;
    int compteur;
    int dizaine = 1;
    int size = my_strlen(str);

    for (compteur = 0; compteur != size - 1; compteur++)
        dizaine *= 10;
    if (str[0] == '-') {
        dizaine /= 10;
        compteur = 1;
    }
    else
        compteur = 0;    
    for (compteur; str[compteur] != '\0'; compteur++) {
        nb = (str[compteur] - 48) * dizaine + nb;
        dizaine /= 10;
    }
    if (str[0] == '-')
        nb *= -1;
    return (nb);
}