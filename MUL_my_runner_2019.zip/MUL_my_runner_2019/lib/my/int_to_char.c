/*
** EPITECH PROJECT, 2019
** char_to_int.c
** File description:
** traduit un int en str
*/

#include"my.h"

char *int_to_char(int nb)
{
    char *str;
    int i = 0;
    int digit;
    int diviseur = 1;
    int compteur = 0;

    for (compteur = 0; nb / (diviseur * 10) != 0; compteur ++)
        diviseur = diviseur * 10;
    str = malloc(sizeof(char) *(compteur + 1));
    if (nb < 0) {
        str[0] = '-';
        nb = nb * - 1;
        i++;
    }
    for(i; i != compteur; i++) {
        str[i] = (nb / diviseur) + 48;
        nb = nb % diviseur;
        diviseur = diviseur / 10 ;
    }
    str[i] = nb + 48;
    str[i + 1] = '\0';
    return (str);
}
