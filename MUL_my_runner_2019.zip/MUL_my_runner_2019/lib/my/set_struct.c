/*
** EPITECH PROJECT, 2019
** MUL_my_runner_2019
** File description:
** set_struct.c
*/

#include"my.h"

void set_decor(decor_t *decor)
{
    sfSprite *sprite = sfSprite_create();
    sfTexture *texture = sfTexture_createFromFile(DECOR, NULL);
    sfIntRect rect = {0, 4, 1229,1076};
    sfMusic *intro = sfMusic_createFromFile(INTRO);
    sfMusic *theme = sfMusic_createFromFile(THEME);
    sfSound *level = sfSound_create();
    sfTexture *cursor_tx = sfTexture_createFromFile(CURSOR, NULL);
    sfSprite *cursor = sfSprite_create();
    sfSoundBuffer *level_effect = sfSoundBuffer_createFromFile(LEVEL);
    sfText *text = sfText_create();
    sfFont *font = sfFont_createFromFile("ressource/fonts/font.ttf");
    sfSprite *sonic = sfSprite_create();
    sfSprite *title = sfSprite_create();
    sfSound *choose = sfSound_create();
    sfSoundBuffer *c_effect = sfSoundBuffer_createFromFile(CHOOSE);
    sfSprite *intro_sp = sfSprite_create();
    sfTexture *tex_intro = sfTexture_createFromFile(MAIN, NULL);

    sfSound_setBuffer(choose, c_effect);
    decor->choose = choose;
    sfSprite_setTexture(sonic, tex_intro, sfTrue);
    sfSprite_setTexture(intro_sp, tex_intro, sfTrue);
    sfSprite_setTexture(title, tex_intro, sfTrue);
    decor->title = title;
    decor->sonic = sonic;
    decor->intro_sp = intro_sp;
    decor->sonic_r = (sfIntRect) {0, 326, 81, 88};
    sfSprite_setTextureRect(decor->intro_sp, (sfIntRect) {0, 0, 270 ,248});
    sfSprite_setTextureRect(decor->sonic, decor->sonic_r);
    sfSprite_setTextureRect(decor->title, (sfIntRect) {0, 424, 220, 74});
    sfSprite_setPosition(decor->sonic, (sfVector2f) {480, 30});
    sfSprite_setPosition(decor->intro_sp, (sfVector2f) {200, 50});
    sfSprite_setScale(decor->sonic, (sfVector2f) {3, 3});
    sfSprite_setPosition(decor->title, (sfVector2f) {266, 263});
    sfSprite_setScale(decor->title, (sfVector2f) {3, 3});
    sfSprite_setScale(decor->intro_sp, (sfVector2f) {3, 3});
    sfSprite_setTexture(cursor, cursor_tx, sfTrue);
    decor->c_rect = (sfIntRect) {0, 0, 21, 23};
    decor->cursor = cursor;
    sfSprite_setScale(decor->cursor, (sfVector2f) {3, 3});
    sfSprite_setTextureRect(decor->cursor, decor->c_rect);
    sfSprite_setPosition(decor->cursor, (sfVector2f) {300, 830});
    sfText_setString(text, "ROUND");
    sfText_setFont(text, font);
    sfSprite_setTexture(sprite, texture, sfTrue);
    decor->sprite = sprite;
    decor->rect = rect;
    sfSprite_setTextureRect(decor->sprite, decor->rect);
    decor->intro = intro;
    decor->theme = theme;
    decor->song = 1;
    sfSound_setBuffer(level, level_effect);
    decor->level = level;
    decor->save = 0;
    decor->limit = 0;
    decor->font = font;
    sfText_setPosition(text, (sfVector2f) {10, -20});
    sfText_setCharacterSize(text, 100);
    decor->round = text;
}

void set_s_sonic(s_sonic_t *s_sonic)
{
    sfMusic *music = sfMusic_createFromFile(STHEME);
    sfSprite *sprite = sfSprite_create();
    sfTexture *texture = sfTexture_createFromFile(SSONIC, NULL);

    sfSprite_setTexture(sprite, texture, sfTrue);
    s_sonic->music = music;
    s_sonic->sprite = sprite;
    s_sonic->rect = (sfIntRect) {122, 0, 122, 264};
    sfSprite_setTextureRect(s_sonic->sprite, s_sonic->rect);
}

void set_bomb(bomb_t *bomb)
{
    sfSprite *sprite = sfSprite_create();
    sfIntRect rect = {0, 0, 203, 203};
    sfTexture *texture = sfTexture_createFromFile(BOMB, NULL);
    sfSoundBuffer *buffer = sfSoundBuffer_createFromFile(EXPLO);
    sfSound *sound = sfSound_create();

    sfSound_setBuffer(sound, buffer);
    bomb->explosion = sound;
    sfSprite_setTexture(sprite, texture, sfFalse);
    bomb->sprite = sprite;
    bomb->rect = rect;
    sfSprite_setTextureRect(bomb->sprite, bomb->rect);
    bomb->pos = (sfVector2f) {600, 520};
    sfSprite_setPosition(bomb->sprite, bomb->pos);
    bomb->texture = texture;
}

void set_sonic(sonic_t *sonic)
{
    sfTexture *death_text = sfTexture_createFromFile(DEATH, NULL);
    sfSprite *death = sfSprite_create();
    sfTexture *texture = sfTexture_createFromFile(SONIC, NULL);
    sfSprite *sprite = sfSprite_create();
    sfSoundBuffer *jump_effect = sfSoundBuffer_createFromFile(JUMP);
    sfSound *jump = sfSound_create();
    sfIntRect rect = {0, 0, 154, 263};
    sfVector2f speed = {0, 0};

    sfSprite_setTexture(death, death_text, sfTrue);
    sonic->death = death;
    sfSprite_setTexture(sprite, texture, sfTrue);
    sonic->sprite = sprite;
    sonic->rect = rect;
    sfSprite_setTextureRect(sonic->sprite, sonic->rect);
    sfSound_setBuffer(jump, jump_effect);
    sonic->jump = jump;
    sonic->pos = (sfVector2f) {520, 740};
    sfSprite_setPosition(sonic->death, (sfVector2f) {450, 700});
    sfSprite_setScale(sonic->death, (sfVector2f) {0.70,0.70});
    sfSprite_setPosition(sonic->sprite,sonic->pos);
    sonic->save = 0;
    sonic->limit = 0;
    sonic->jumping = 0;
    sonic->speed = speed;
    sonic->kmh = 10;
}

void set_B_effect(B_effect_t *B_effect)
{
    sfTexture *text1 = sfTexture_createFromFile(BEFF1, NULL);
    sfTexture *text2 = sfTexture_createFromFile(BEFF2, NULL);
    sfTexture *text3 = sfTexture_createFromFile(BEFF3, NULL);
    sfSprite *spr_1 = sfSprite_create();
    sfSprite *spr_2 = sfSprite_create();
    sfSprite *spr_3 = sfSprite_create();
    sfSprite *spr_4 = sfSprite_create();

    sfSprite_setTexture(spr_1, text1, sfTrue);
    sfSprite_setTexture(spr_2, text2, sfTrue);
    sfSprite_setTexture(spr_3, text3, sfTrue);
    sfSprite_setTexture(spr_4, text3, sfTrue);
    B_effect->spr_1 = spr_1;
    B_effect->spr_2 = spr_2;
    B_effect->spr_3 = spr_3;
    B_effect->spr_4 = spr_4;
    sfSprite_setPosition(B_effect->spr_4, (sfVector2f) {0, 1076});
}

void set_start(start_t *start)
{
    sfTexture *texture = sfTexture_createFromFile(ALL, NULL);
    sfSprite *sprite = sfSprite_create();
    sfVector2f size = (sfVector2f) {4, 4};

    sfSprite_setTexture(sprite, texture, sfTrue);
    sfSprite_setTextureRect(sprite, (sfIntRect) {761, 2984, 150, 32});
    start->sprite = sprite;
    start->size = size;
    sfSprite_setScale(start->sprite, start->size);
    start->pos = (sfVector2f) {300, -128};
    sfSprite_setPosition(start->sprite, start->pos);
    start->value = 0;
    start->max_pos = (sfVector2f) {300, 400};
    start->max_size = (sfVector2f) {12 , 12};
}

void set_all(lvl_all_t *lvl_all)
{
    int value;
    char *filepath = "ressource/map/map";

    value = open(filepath, O_RDONLY);
    filepath = map_is(filepath);
    lvl_all->map = filepath;
    lvl_all->decor = malloc(sizeof(decor_t) *(1));
    lvl_all->sonic = malloc(sizeof(sonic_t) *(1));
    lvl_all->start = malloc(sizeof(start_t) *(1));
    lvl_all->B_effect = malloc(sizeof(B_effect_t) *(1));
    lvl_all->bomb = malloc(sizeof(bomb_t) *(1));
    set_decor(lvl_all->decor);
    set_sonic(lvl_all->sonic);
    set_start(lvl_all->start);
    set_B_effect(lvl_all->B_effect);
    set_bomb(lvl_all->bomb);
}