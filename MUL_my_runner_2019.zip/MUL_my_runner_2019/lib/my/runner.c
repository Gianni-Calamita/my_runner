/*
** EPITECH PROJECT, 2019
** MUL_my_runner_2019
** File description:
** runner.c
*/

#include"my.h"

void time_effect(decor_t *decor,float *second, sonic_t *sonic, start_t *start)
{
    int sec = *second;

    if (sec - decor->save >sonic->kmh * 2 - 6) {
        decor->rect.left += 1242;
        if (decor->limit >= 3) {
            decor->limit = -1;
            decor->rect.left = 0;
        }
        sfSprite_setTextureRect(decor->sprite, decor->rect);
        decor->save = sec;
        decor->limit++;
    }
    if (sec - sonic->save >= sonic->kmh && sonic->jumping == 0) {
        sonic->rect.left += 155;
        if (sonic->limit >= 6) {
            sonic->limit = -1;
            sonic->rect.left = 0;
        }
        sfSprite_setTextureRect(sonic->sprite, sonic->rect);
        sonic->save = sec;
        sonic->limit++;
    }
    if (*second >= 500 && start->value == 0)
        start->value = 3;
    if (*second >= 1138 && decor->song != 0) {
        decor->song = 0;
        sfMusic_stop(decor->intro);
        sfMusic_play(decor->theme);
        sfMusic_setLoop(decor->theme, sfTrue);
    }
}

void sonic_jump(sonic_t *sonic, float *second)
{
    sonic->pos = sfSprite_getPosition(sonic->sprite);
    if (sonic->pos.y >= 720 && sonic->speed.y > 0 ) {
            sonic->speed.y = 0;
            sonic->jumping = 0;
            sonic->rect.left = 0;
            sonic->pos.y = 740;
            sfSprite_setPosition(sonic->sprite,sonic->pos);
            return;
    }
    if (*second - sonic->save >= sonic->kmh) {
        sonic->rect.left += 155;
        if (sonic->limit >= 1) {
            sonic->limit = -1;
            sonic->rect.left = 1240;
        }
        sfSprite_setTextureRect(sonic->sprite, sonic->rect);
        sonic->save = *second;
        sonic->limit++;
    }
    if (*second - sonic->save >= sonic->kmh/2) {
        if (sonic->speed.y <= -10)
            sonic->speed.y-= 5;
        if (sonic->speed.y >= 2 && 
         sonic->speed.y <= 60)
            sonic->speed.y*= 2;
    }
    if (sonic->pos.y <= 200)
        sonic->speed.y = 20;

}

void pos_b_effect(B_effect_t *B_effect)
{
    sfVector2f position = sfSprite_getPosition(B_effect->spr_1);

    if (position.x < -1227)
        sfSprite_setPosition(B_effect->spr_1, (sfVector2f) {1227, 0});
    position = sfSprite_getPosition(B_effect->spr_2);
    if (position.x > 1227)
        sfSprite_setPosition(B_effect->spr_2, (sfVector2f) {-1227, 0});
    position = sfSprite_getPosition(B_effect->spr_3);
    if (position.y < -1076)
        sfSprite_setPosition(B_effect->spr_3, (sfVector2f) {0, 1076});
    position = sfSprite_getPosition(B_effect->spr_4);
    if (position.y < -1076)
        sfSprite_setPosition(B_effect->spr_4, (sfVector2f) {0, 1076});
}

void game(sfRenderWindow *window)
{
    sfEvent event;
    sfClock *clock = sfClock_create();
    sfTime time;
    lvl_all_t lvl_all;
    float second;

    set_all(&lvl_all);
    sfMusic_play(lvl_all.decor->intro);
    while (sfRenderWindow_isOpen(window) && second < 1200) {
        sfRenderWindow_clear(window, sfBlack);
        time = sfClock_getElapsedTime(clock);
        second = time.microseconds / 10000;
        while (sfRenderWindow_pollEvent(window, &event)) {
            if (event.type == sfEvtClosed || sfKeyboard_isKeyPressed(sfKeyEscape))
                sfRenderWindow_close(window);
            if (sfKeyboard_isKeyPressed(sfKeySpace) && lvl_all.sonic->jumping == 0) {
                sfSound_play(lvl_all.sonic->jump);
                lvl_all.sonic->jumping = 1;
                lvl_all.sonic->speed.y = -30;
                lvl_all.sonic->limit = 0;
                lvl_all.sonic->rect.left = 1240; 
            }
        }
        lvl_all.start->pos = sfSprite_getPosition(lvl_all.start->sprite);
        if (lvl_all.start->pos.y < lvl_all.start->max_pos.y && lvl_all.start->value == 0)
            sfSprite_move(lvl_all.start->sprite, (sfVector2f) {0, 6});
        if (lvl_all.start->value == 3) {
            lvl_all.start->size = (sfVector2f) {lvl_all.start->size.x + 4, lvl_all.start->size.y + 4};
            lvl_all.start->pos = (sfVector2f) {600 - (lvl_all.start->size.x * 150)/2  , 463 - (lvl_all.start->size.y * 32)/2};
            sfSprite_setScale(lvl_all.start->sprite, lvl_all.start->size);
            sfSprite_setPosition(lvl_all.start->sprite, lvl_all.start->pos);
            if (lvl_all.start->size.y >= 70.0) {
                lvl_all.start->value = 1;
                sfSprite_destroy(lvl_all.start->sprite);
            }
        }
        if (lvl_all.sonic->jumping == 1)
            sonic_jump(lvl_all.sonic, &second);
        pos_b_effect(lvl_all.B_effect);
        time_effect(lvl_all.decor, &second, lvl_all.sonic, lvl_all.start);
        sfSprite_move(lvl_all.sonic->sprite, lvl_all.sonic->speed);
        sfSprite_move(lvl_all.B_effect->spr_1, (sfVector2f) {-lvl_all.sonic->kmh * 2, 0});
        sfSprite_move(lvl_all.B_effect->spr_2, (sfVector2f) {lvl_all.sonic->kmh, 0});
        sfSprite_move(lvl_all.B_effect->spr_3, (sfVector2f) {0, -lvl_all.sonic->kmh*1.5});
        sfSprite_move(lvl_all.B_effect->spr_4, (sfVector2f) {0, -lvl_all.sonic->kmh*1.5});
        sfRenderWindow_drawSprite(window, lvl_all.B_effect->spr_4, NULL);
        sfRenderWindow_drawSprite(window, lvl_all.B_effect->spr_3, NULL);
        sfRenderWindow_drawSprite(window, lvl_all.B_effect->spr_1, NULL);
        sfRenderWindow_drawSprite(window, lvl_all.B_effect->spr_2, NULL);
        sfRenderWindow_drawSprite(window, lvl_all.decor->sprite, NULL);
        sfRenderWindow_drawSprite(window, lvl_all.sonic->sprite, NULL);
        sfRenderWindow_drawText(window, lvl_all.decor->round, NULL);
        if (lvl_all.start->value != 1)
            sfRenderWindow_drawSprite(window, lvl_all.start->sprite, NULL);
        sfRenderWindow_display(window);
    }
    game_begin(&lvl_all, window, 0);
    return;
}

void runner()
{
    sfRenderWindow *window;
    sfVideoMode mode = {1227, 1076, 32};
    int left = 0;

    window = sfRenderWindow_create(mode, TITLE, sfDefaultStyle, NULL);
    sfRenderWindow_setPosition(window, (sfVector2i) {360, 0});
    sfRenderWindow_setFramerateLimit(window, 30);
    sfRenderWindow_setMouseCursorVisible(window, sfFalse);
    menu(window, &left);
    if (left == 1)
        return;
    game(window);
}
