/*
** EPITECH PROJECT, 2019
** MUL_my_runner_2019
** File description:
** game.c
*/

#include"my.h"

void set_new_bomb(bomb_t *bomb, int *bomb_nb)
{
    bomb->pos = (sfVector2f) {600, 520};
    bomb->scale = (sfVector2f) {0.05, 0.05};
    sfSprite_setTexture(bomb->sprite, bomb->texture, sfTrue);
    sfSprite_setScale(bomb->sprite, bomb->scale);
    sfSprite_setTextureRect(bomb->sprite, bomb->rect);
    sfSprite_setPosition(bomb->sprite, bomb->pos);
    bomb->save = 500;
    (*bomb_nb) = 1;
}

void see_the_bomb(bomb_t *bomb, float second)
{
    sfVector2f pos_y;

    pos_y = sfSprite_getPosition(bomb->sprite);
    bomb->pos = sfSprite_getPosition(bomb->sprite);
    if (pos_y.y - bomb->save >= 8) {
        sfSprite_setPosition(bomb->sprite, (sfVector2f) {600 - (bomb->scale.x * 203)/2, bomb->pos.y});
        bomb->scale = (sfVector2f) {bomb->scale.x + 0.05, bomb->scale.y + 0.05}; 
        sfSprite_setScale(bomb->sprite, bomb->scale);
        bomb->save = pos_y.y;
    }
}

void round_lvl(int round, sfText **lvl, decor_t *decor)
{
    sfText_setString(*lvl, int_to_char(round + 1));
    sfText_setFont(*lvl, decor->font);
    sfText_setCharacterSize(*lvl, 100);
    sfText_setPosition(*lvl, (sfVector2f) {233, -20});
}

int game_begin(lvl_all_t *lvl_all, sfRenderWindow *window, int round)
{
    sfEvent event;
    sfClock *clock = sfClock_create();
    sfTime time;
    sfText *lvl = sfText_create();
    float second;
    int rang = 0;
    int save = 0;
    int bomb = 0;
    int loose = 0;

    round_lvl(round, &lvl, lvl_all->decor);
    lvl_all->sonic->save = 0;
    lvl_all->decor->save = 0;
    while (sfRenderWindow_isOpen(window) && lvl_all->map[rang] != '\0' && loose == 0) {
        time = sfClock_getElapsedTime(clock);
        save = time.microseconds / 10000;
        bomb = 0;
        if (lvl_all->map[rang] == 'x')
            set_new_bomb(lvl_all->bomb, &bomb);
        while (second - save  < lvl_all->sonic->kmh * 50  && sfRenderWindow_isOpen(window) 
                && loose != 1) {
            sfRenderWindow_clear(window, sfBlack);
            time = sfClock_getElapsedTime(clock);
            second = time.microseconds / 10000;
            while (sfRenderWindow_pollEvent(window, &event)) {
                if (event.type == sfEvtClosed || sfKeyboard_isKeyPressed(sfKeyEscape))
                    sfRenderWindow_close(window);
                if (sfKeyboard_isKeyPressed(sfKeySpace) && lvl_all->sonic->jumping == 0) {
                    sfSound_play(lvl_all->sonic->jump);
                    lvl_all->sonic->jumping = 1;
                    lvl_all->sonic->speed.y = -30;
                    lvl_all->sonic->limit = 0;
                    lvl_all->sonic->rect.left = 1240; 
                }
            }
            if (lvl_all->sonic->jumping == 1)
                sonic_jump(lvl_all->sonic, &second);
            pos_b_effect(lvl_all->B_effect);
            time_effect(lvl_all->decor, &second, lvl_all->sonic, lvl_all->start);
            sfSprite_move(lvl_all->sonic->sprite, lvl_all->sonic->speed);
            sfSprite_move(lvl_all->B_effect->spr_1, (sfVector2f) {-lvl_all->sonic->kmh * 2, 0});
            sfSprite_move(lvl_all->B_effect->spr_2, (sfVector2f) {lvl_all->sonic->kmh, 0});
            sfSprite_move(lvl_all->B_effect->spr_3, (sfVector2f) {0, -lvl_all->sonic->kmh*1.5});
            sfSprite_move(lvl_all->B_effect->spr_4, (sfVector2f) {0, -lvl_all->sonic->kmh*1.5});
            sfRenderWindow_drawSprite(window, lvl_all->B_effect->spr_4, NULL);
            sfRenderWindow_drawSprite(window, lvl_all->B_effect->spr_3, NULL);        
            sfRenderWindow_drawSprite(window, lvl_all->B_effect->spr_1, NULL);
            sfRenderWindow_drawSprite(window, lvl_all->B_effect->spr_2, NULL);
            sfRenderWindow_drawSprite(window, lvl_all->decor->sprite, NULL);
            if (bomb == 1 && lvl_all->bomb->scale.y <= 1.25) {
                see_the_bomb(lvl_all->bomb, second); 
                sfSprite_move(lvl_all->bomb->sprite, (sfVector2f) {0, 1300/(lvl_all->sonic->kmh * 50)});
                sfRenderWindow_drawSprite(window, lvl_all->bomb->sprite, NULL);
            }
            if (bomb == 1 && lvl_all->bomb->scale.x > 1.25 && lvl_all->bomb->scale.y < 1.35) {
                lvl_all->sonic->pos = sfSprite_getPosition(lvl_all->sonic->sprite);
                if (lvl_all->sonic->pos.y >= 720 && lvl_all->sonic->jumping == 0) {
                    loose = 1;
                }
                see_the_bomb(lvl_all->bomb, second);
                sfSprite_move(lvl_all->bomb->sprite, (sfVector2f) {0, 1300/(lvl_all->sonic->kmh * 30)});
                sfRenderWindow_drawSprite(window, lvl_all->bomb->sprite, NULL);
            }
            sfRenderWindow_drawSprite(window, lvl_all->sonic->sprite, NULL);
            if (bomb == 1 && lvl_all->bomb->scale.y >= 1.35) {
                see_the_bomb(lvl_all->bomb, second);
                sfSprite_move(lvl_all->bomb->sprite, (sfVector2f) {0, 1300/(lvl_all->sonic->kmh * 20)});
                sfRenderWindow_drawSprite(window, lvl_all->bomb->sprite, NULL);
            }
            sfRenderWindow_drawText(window, lvl_all->decor->round, NULL);
            sfRenderWindow_drawText(window, lvl, NULL);
            sfRenderWindow_display(window);
        }
        sfSprite_setTexture(lvl_all->bomb->sprite, lvl_all->bomb->texture, sfFalse);
        rang++;
    }
    if (loose == 1 && sfRenderWindow_isOpen(window)) {
        sfMusic_stop(lvl_all->decor->theme);
        end(lvl_all, window, round);
    }
    if (loose == 0 && sfRenderWindow_isOpen(window) && round != 6){
        lvl_all->sonic->kmh --;
        if (lvl_all->sonic->kmh < 5)
            lvl_all->sonic->kmh = 5;
        game_begin(lvl_all, window, round + 1);
    }
    if (loose == 0 && sfRenderWindow_isOpen(window) && round == 6)
        super_sonic(lvl_all, window, round + 1);
    return (0);
}