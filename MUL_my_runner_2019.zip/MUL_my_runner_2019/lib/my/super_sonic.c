/*
** EPITECH PROJECT, 2019
** MUL_my_runner_2019
** File description:
** super_sonic.c
*/

#include"my.h"

void animation(sfRenderWindow *window, lvl_all_t *lvl_all, s_sonic_t *s_sonic)
{
    sfClock *clock = sfClock_create();
    sfTime time;
    float second;
    int sprite = 0;
    int s_sprite = 0;

    lvl_all->sonic->save = 0;
    sfClock_restart(clock);
    lvl_all->sonic->rect.left = 1240;
    sfSprite_setTextureRect(lvl_all->sonic->sprite, lvl_all->sonic->rect);
    sfSound_play(lvl_all->sonic->jump);
    s_sonic->rect.width = 155;
    while (second < 800) {
        if (second < 300)
            sfRenderWindow_clear(window, sfBlack);
        else
            sfRenderWindow_clear(window, sfWhite);
        time = sfClock_getElapsedTime(clock);
        second = time.microseconds / 10000;
        lvl_all->sonic->pos = sfSprite_getPosition(lvl_all->sonic->sprite); 
        if (second - lvl_all->sonic->save > 2 && second < 300) {
            if (sprite == 0) {
                lvl_all->sonic->rect.left += 155;
                sprite = 1;
            }
            else {
                lvl_all->sonic->rect.left = 1240;
                sprite = 0;
            }
            lvl_all->sonic->save = second;
            sfSprite_setTextureRect(lvl_all->sonic->sprite, lvl_all->sonic->rect);
        }
        if (second - lvl_all->sonic->save > 2 && second >= 300) {
            if (s_sprite == 0) {
                s_sonic->rect.left = 277;
                s_sprite = 1;
            }
            else {
                s_sonic->rect.left = 122;
                s_sprite = 0;
            }
            lvl_all->sonic->save = second;
            sfSprite_setTextureRect(s_sonic->sprite, s_sonic->rect);
        }
        if (lvl_all->sonic->pos.y > 350)
            sfSprite_move(lvl_all->sonic->sprite, (sfVector2f) {0, -15});
        sfRenderWindow_drawSprite(window, lvl_all->decor->sprite, NULL);
        if (second < 300) {
            sfRenderWindow_drawSprite(window, lvl_all->sonic->sprite, NULL);
        }
        else {
            sfSprite_setPosition(s_sonic->sprite, lvl_all->sonic->pos);
            sfRenderWindow_drawSprite(window, s_sonic->sprite, NULL);
        }
        sfRenderWindow_display(window);
    }
    s_sonic->rect.width = 122;
    s_sonic->rect.left = 0;
    sfSprite_setTextureRect(s_sonic->sprite, s_sonic->rect);
}

void super_sonic(lvl_all_t *lvl_all, sfRenderWindow *window, int round)
{
    sfClock *clock = sfClock_create();
    sfTime time;
    sfText *lvl = sfText_create();
    s_sonic_t s_sonic;
    float second;
    int rang = 0;
    int save = 0;
    int down = 1;
    sfVector2f up = sfSprite_getPosition(lvl_all->sonic->sprite);
    int pause = 0;
    int bomb = 0;

    set_s_sonic(&s_sonic);
    sfMusic_stop(lvl_all->decor->theme);
    round_lvl(round, &lvl, lvl_all->decor);
    lvl_all->sonic->save = 0;
    lvl_all->decor->save = 0;
    sfMusic_play(s_sonic.music);
    animation(window, lvl_all, &s_sonic);
    lvl_all->sonic->pos = up;
    lvl_all->sonic->kmh = 3;
    sfSprite_setPosition(lvl_all->sonic->sprite, lvl_all->sonic->pos);
    sfSprite_setPosition(s_sonic.sprite, (sfVector2f) {lvl_all->sonic->pos.x + 30, 400});
    while (sfRenderWindow_isOpen(window) && lvl_all->map[rang] != '\0') {
        time = sfClock_getElapsedTime(clock);
        save = time.microseconds / 10000;
        bomb = 0;
        if (lvl_all->map[rang] == 'x')
            set_new_bomb(lvl_all->bomb, &bomb);
        while (second - save  < lvl_all->sonic->kmh * 50  && sfRenderWindow_isOpen(window)) {
            sfRenderWindow_clear(window, sfWhite);
            time = sfClock_getElapsedTime(clock);
            second = time.microseconds / 10000;
            pos_b_effect(lvl_all->B_effect);
            time_effect(lvl_all->decor, &second, lvl_all->sonic, lvl_all->start);
            sfSprite_move(lvl_all->B_effect->spr_1, (sfVector2f) {-lvl_all->sonic->kmh * 2, 0});
            sfSprite_move(lvl_all->B_effect->spr_2, (sfVector2f) {lvl_all->sonic->kmh, 0});
            sfSprite_move(lvl_all->B_effect->spr_3, (sfVector2f) {0, -lvl_all->sonic->kmh*1.5});
            sfSprite_move(lvl_all->B_effect->spr_4, (sfVector2f) {0, -lvl_all->sonic->kmh*1.5});
            sfRenderWindow_drawSprite(window, lvl_all->B_effect->spr_4, NULL);
            sfRenderWindow_drawSprite(window, lvl_all->B_effect->spr_3, NULL);        
            sfRenderWindow_drawSprite(window, lvl_all->B_effect->spr_1, NULL);
            sfRenderWindow_drawSprite(window, lvl_all->B_effect->spr_2, NULL);
            sfRenderWindow_drawSprite(window, lvl_all->decor->sprite, NULL);
            if (bomb == 1 && lvl_all->bomb->scale.y <= 1.25) {
                see_the_bomb(lvl_all->bomb, second); 
                sfSprite_move(lvl_all->bomb->sprite, (sfVector2f) {0, 1300/(lvl_all->sonic->kmh * 50)});
                sfRenderWindow_drawSprite(window, lvl_all->bomb->sprite, NULL);
            }
            sfRenderWindow_drawSprite(window, s_sonic.sprite, NULL);
            if (bomb == 1 && lvl_all->bomb->scale.y > 1.25) {
                see_the_bomb(lvl_all->bomb, second);
                sfSprite_move(lvl_all->bomb->sprite, (sfVector2f) {0, 1300/(lvl_all->sonic->kmh * 20)});
                sfRenderWindow_drawSprite(window, lvl_all->bomb->sprite, NULL);
            }
            sfRenderWindow_drawText(window, lvl_all->decor->round, NULL);
            sfRenderWindow_drawText(window, lvl, NULL);
            sfRenderWindow_display(window);
        }
        sfSprite_setTexture(lvl_all->bomb->sprite, lvl_all->bomb->texture, sfFalse);
        rang++;
    }
    sfMusic_stop(s_sonic.music);
    sfMusic_play(lvl_all->decor->theme);
    lvl_all->sonic->kmh = 5;
    game_begin(lvl_all, window, round + 1);
}