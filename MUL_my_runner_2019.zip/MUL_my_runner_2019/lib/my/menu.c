/*
** EPITECH PROJECT, 2019
** MUL_my_runner_2019
** File description:
** menu.c
*/

#include"my.h"

void menu(sfRenderWindow *window, int *left)
{
    decor_t decor;
    sfEvent event;
    int spam = 0;
    sfMusic *music = sfMusic_createFromFile(MENU);
    int selection = 0;
    sfClock *clock = sfClock_create();
    sfTime time;
    float second;
    int save = 0;
    int ani = 0;

    set_decor(&decor);
    sfMusic_play(music);
    sfSprite_setPosition(decor.cursor, (sfVector2f) {380, 490});
    while (sfRenderWindow_isOpen(window)) {
        sfRenderWindow_clear(window, sfBlack);
        time = sfClock_getElapsedTime(clock);
        second = time.microseconds / 100000;
        while (sfRenderWindow_pollEvent(window, &event)) {
            if (event.type == sfEvtClosed || sfKeyboard_isKeyPressed(sfKeyEscape))
                sfRenderWindow_close(window);
        }
        if (sfKeyboard_isKeyPressed(sfKeyEnter)) {
            if (selection == 1) {
                sfRenderWindow_close(window);
                *left = 1;
            }
            sfMusic_stop(music);
            return;
        }
        if (sfKeyboard_isKeyPressed(sfKeyUp) || sfKeyboard_isKeyPressed(sfKeyDown)) {
            if (selection == 0 && spam != 1) {
                sfSound_play(decor.choose);
                selection = 1;
                sfSprite_setPosition(decor.cursor, (sfVector2f) {400, 580});
                spam = 1;
            }
            if (selection == 1 && spam != 1) {
                sfSound_play(decor.choose);
                selection = 0;
                spam = 1;
                sfSprite_setPosition(decor.cursor, (sfVector2f) {380, 490});
            } 
        }
        else
            spam = 0;
        if (second - save > 1) {
            save = second;
            if (ani == 0) {
                ani++;
                sfSprite_setTextureRect(decor.sonic, (sfIntRect) {81, 326, 81, 88});
            }
            else {
                ani = 0;
                sfSprite_setTextureRect(decor.sonic, decor.sonic_r);
            }
        }
        sfRenderWindow_drawSprite(window, decor.intro_sp, NULL);
        sfRenderWindow_drawSprite(window, decor.sonic, NULL);
        sfRenderWindow_drawSprite(window, decor.title, NULL);
        sfRenderWindow_drawSprite(window, decor.cursor, NULL);
        sfRenderWindow_display(window);
    }
}