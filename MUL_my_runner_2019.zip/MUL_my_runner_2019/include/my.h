/*
** EPITECH PROJECT, 2019
** my.h
** File description:
** contient tous les protorype de la bibliotheque
*/

#include<stdarg.h>
#include<unistd.h>
#include<fcntl.h>
#include<sys/types.h>
#include<sys/stat.h>
#include<SFML/Window.h>
#include<SFML/Audio.h>
#include<SFML/Config.h>
#include<SFML/Graphics.h>
#include<SFML/System/Export.h>
#include<SFML/System/Time.h>
#include<SFML/System/Types.h>
#include<SFML/Graphics/Export.h>
#include<stdlib.h>
#include"struct.h"

#define DECOR "ressource/sprite/stage.png"
#define SONIC "ressource/sprite/sonic.png"
#define DEATH "ressource/sprite/death.png"
#define BEFF1 "ressource/background/first.png"
#define BEFF2 "ressource/background/second.png"
#define BEFF3 "ressource/background/third(backgroung).png"
#define ALL "ressource/sprite/decor.png"
#define BOMB "ressource/sprite/bomb.png"
#define MAIN "ressource/sprite/intro.png"
#define CURSOR "ressource/sprite/cursor.png"
#define SSONIC "ressource/sprite/super_sonic.png"

#define JUMP "ressource/audio/effect/jump.ogg"
#define CHOOSE "ressource/audio/effect/choose.ogg"
#define EXPLO "ressource/audio/effect/bomb.ogg"

#define THEME "ressource/audio/song/level_music_loop.ogg"
#define INTRO "ressource/audio/song/level_music_intro.ogg"
#define WIN "ressource/audio/song/win.ogg"
#define LOOSE "ressource/audio/song/loose.ogg"
#define MENU "ressource/audio/song/menue.ogg"
#define LEVEL "ressource/audio/effect/level.ogg"
#define STHEME "ressource/audio/song/s_sonic.ogg"

#define FONT "ressource/fonts/font.ttf"

#define TITLE "SONIC 2 - runner GIANNI.CALAMITA"
#define ERROR (84)

int my_strlen(char *str);
void my_putchar(char c);
void my_putstr(char *str);
void my_putnbr(int nb);
int my_printf(char *str, ...);
void my_putunbr(unsigned int nb);
void my_puthex(int nb);
void my_putoctal(int nb);
void my_putbinary(int nb);
int char_to_int(char *str);
void my_puthex_maj(int nb);
char *int_to_char(int nb);
void letter_is_x_maj(va_list start);
void letter_is_d(va_list start);
void letter_is_i(va_list start);
void letter_is_u(va_list start);
void letter_is_s(va_list start);
void letter_is_c(va_list start);
void letter_is_x(va_list start);
void letter_is_o(va_list start);
void letter_is_b(va_list start);
void set_decor(decor_t *decor);
void set_sonic(sonic_t *sonic);
void set_B_effect(B_effect_t *B_effect);
int my_checkstr(char *str, char *check);
int print_help(void);
int check_error(char const *filepath);
void read_file(char *filepath);
int check_error_map();
void runner();
char *map_is(char *filepath);
void set_start(start_t *start);
void set_all(lvl_all_t *lvl_all);
int game_begin(lvl_all_t *lvl_all_t, sfRenderWindow *window, int round);
void pos_b_effect(B_effect_t *B_effect);
void sonic_jump(sonic_t *sonic, float *second);
void time_effect(decor_t *decor,float *second, sonic_t *sonic, start_t *start);
void end(lvl_all_t *lvl_all, sfRenderWindow *window, int round);
void game(sfRenderWindow *window);
void menu(sfRenderWindow *window, int *left);
void round_lvl(int round, sfText **lvl, decor_t *decor);
void super_sonic(lvl_all_t *lvl_all, sfRenderWindow *window, int round);
void set_s_sonic(s_sonic_t *s_sonic);
void set_new_bomb(bomb_t *bomb, int *bomb_nb);
void see_the_bomb(bomb_t *bomb, float second);