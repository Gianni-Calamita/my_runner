/*
** EPITECH PROJECT, 2019
** PSU_my_printf_bootstrap_2019
** File description:
** unit_test.c
*/

#include<criterion/criterion.h>
#include<criterion/redirect.h>
#include "my.h"

void  redirect_all_std(void)
{
    cr_redirect_stdout ();
    cr_redirect_stderr ();
}

Test(fs_open_file , succes_fonction_fs_open_file , .init = redirect_all_std)
{
    fs_open_file("fichier_de_lecture_de_test");
    cr_assert_stdout_eq_str("SUCCESS\n");
}

Test(fs_open_file , failled_fonction_fs_open_file , .init = redirect_all_std)
{
    fs_open_file("rien");
    cr_assert_stdout_eq_str("FAILURE\n");
}
